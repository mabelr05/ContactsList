package ec.edu.tecnologicoloja.listapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.NumberPicker;
import android.widget.TextView;

import java.util.ArrayList;

import ec.edu.tecnologicoloja.listapplication.adapter.ListAdapter;
import ec.edu.tecnologicoloja.listapplication.database.Persona;
import ec.edu.tecnologicoloja.listapplication.database.PersonaLab;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemClickListener {

    private ListAdapter listItemAdapter;
    private ArrayList<Persona> listaNombres = new ArrayList<>();
    private ListView listView;
    private PersonaLab mPersonaLab;
    private Persona mPersona;
    private TextView et_nombre, et_apellido, et_telefono, et_email, et_descripcion;
    private Button bguardar, blimpiar;
    private NumberPicker pk_ciudad;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mPersonaLab = new PersonaLab(this);

        listView = (ListView) findViewById(R.id.list);
        listView.setOnItemClickListener(this);
        et_nombre = (TextView) findViewById(R.id.editTextTextPersonName);
        et_apellido = findViewById(R.id.etPersonApe);
        et_telefono = findViewById(R.id.etPhone);
        et_email = findViewById(R.id.etEmailAddress);
        et_descripcion = findViewById(R.id.etDescripcion);
        bguardar = (Button) findViewById(R.id.buttonGuardar);
        blimpiar = (Button) findViewById(R.id.buttonLimpiar);
        bguardar.setOnClickListener(this);
        blimpiar.setOnClickListener(this);
        pk_ciudad = findViewById(R.id.pkCiudad);
        String[] cities = {"Quito", "Guayaquil", "Cuenca", "Manta", "Ambato", "Loja"};
        pk_ciudad.setMinValue(0);
        pk_ciudad.setMaxValue(cities.length - 1);
        pk_ciudad.setDisplayedValues(cities);


        getAllPersonas();
        listItemAdapter = new ListAdapter(this, listaNombres);
        listView.setAdapter(listItemAdapter);


    }

    /**
     * GUARDA EN LA BASE DE DATOS
     */
    public void insertPersonas() {
        mPersona = new Persona();
        mPersona.setNombre(et_nombre.getText().toString());
        mPersona.setApellido(et_apellido.getText().toString());
        mPersona.setTelefono(et_telefono.getText().toString());
        mPersona.setEmail(et_email.getText().toString());
        mPersona.setDescripcion(et_descripcion.getText().toString());
        String[] cities = {"Quito", "Guayaquil", "Cuenca", "Manta", "Ambato", "Loja"};
// Obtener la ciudad seleccionada
        int selectedCityIndex = pk_ciudad.getValue();
        String selectedCity = cities[selectedCityIndex];
// Establecer la ciudad seleccionada en mPersona
        mPersona.setCiudad(selectedCity);
        mPersonaLab.addPersona(mPersona);
        et_nombre.setText("");
        et_apellido.setText("");
        et_telefono.setText("");
        et_descripcion.setText("");
        et_email.setText("");

    }

    // CONSULTA A LA BASE DE DATOS
    public void getAllPersonas() {
        listaNombres.clear();
        listaNombres.addAll(mPersonaLab.getPersonas());

    }

    // ACCION DE LOS BOTONES
    @Override
    public void onClick(View v) {
        if (v == blimpiar) {
            mPersonaLab.deleteAllPersona();
            listaNombres.clear();
            listItemAdapter.notifyDataSetChanged();
        }
        if (v == bguardar) {
            insertPersonas();
            getAllPersonas();
            listItemAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = new Intent();
        intent.setClass(MainActivity.this, ContactActivity.class);
        String idd = "" + listaNombres.get(position).getId();
        intent.putExtra("id", idd);
        startActivity(intent);
    }
}